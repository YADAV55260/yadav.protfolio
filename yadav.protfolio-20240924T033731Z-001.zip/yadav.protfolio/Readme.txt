Thanks for downloading this template!

Template Name: Kelly
Template URL: https://bootstrapmade.com/kelly-free-bootstrap-cv-resume-html-template/
Author: BootstrapMade.com
License: https://bootstrapmade.com/license/
